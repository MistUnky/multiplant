Mod for Minetest
This adds Multiplants to the game. Multiplants can grow on farmland and switch to any other plant or flower if grown.

Licence for code:
GPLv3 or later

Licence for media:
CC-BY-SA
